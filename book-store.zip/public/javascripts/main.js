$(document).ready(function () {
    listReaders();
    fillSelectBooks();
    fillSelectNames();
    listRents();
});

function getRequest(url, callback) {
    let jqxhr = $.ajax({url: url});
    jqxhr.done(data => callback(data));
    jqxhr.fail(err => {
        console.error(err);
        Swal.fire("Error", err.responseText, "error");
    });
}

/******************CUSTOMER SCRIPTS******************/


function subCust() {
    var formData ={
        customersfname: $('#fname').val(),
        customerslname: $('#lname').val(),
        customersaddress: $('#email').val(),
        customersphone: $('#phone').val()
    };

    $.ajax({
        url: '/customers/savecust',
        type: 'POST',
        data: formData,
        success: (data, status) => {
            if (status === 'success') {
                alert('Reader Saved successfully!');
                listReaders();
                clearCust();
            }
        }
    })
}

function clearCust() {
    $('#fname').val('');
    $('#lname').val('');
    $('#email').val('');
    $('#phone').val('');
}

function listReaders(){
    $.ajax({
        url: '/customers/listreaders',
        type: 'GET',
        success: (data, status) => {
            if (status === 'success'){
                displayData(JSON.parse(data));
            }
        }
    })
}

function displayData(readers){
    var toPrint = "";

    readers.forEach(customers => {
        toPrint += `<tr>
                        <td>${customers.customersid}</td>
                        <td>${customers.customersfname}</td>
                        <td>${customers.customerslname}</td>
                        <td>${customers.customersaddress}</td>
                        <td>${customers.customersphone}</td>
                        <td style="padding:0">
                            <button class="btn btn-link" onclick="deleteCustomer(${customers.customersid})"><i class="fa fa-trash"></i></button>
                            <button class="btn btn-link" onclick=\'editCustomer(${JSON.stringify(customers)})\'><i class="fa fa-edit"></i></button>
                        </td>
                    </tr>`
    });

    $('#print-cust').html(toPrint);
}

function deleteCustomer(id){
    $.ajax({
        url: `/customers/deletecustomer/${id}`,
        type: 'DELETE',
        success: (data, status) => {
            if (status === 'success'){
                alert('Customer deleted successfully!');
                listReaders();
            }
        }
    })
}

function editCustomer(customers){
    $('#ufname').val(customers.customersfname);
    $('#ulname').val(customers.customerslname);
    $('#uaddress').val(customers.customersaddress);
    $('#uphone').val(customers.customersphone);
    $('#uid').val(customers.customersid);
    $('#editCustModal').modal('show');
}

function saveCustChanges() {
    var formData ={
        customersfname: $('#ufname').val(),
        customerslname: $('#ulname').val(),
        customersaddress: $('#uaddress').val(),
        customersphone: $('#uphone').val()
    }
    var id = $('#uid').val();

    $.ajax({
        url: `/customers/updatecustomer/${id}`,
        type: 'POST',
        data: formData,
        success: (data, status) => {
            if (status === 'success'){
                alert('Customer updated successfully!');
                $('#editCustModal').modal('hide');
                listReaders();
            }
        }
    })
}

/******************BOOK SCRIPTS******************/

$('#sub-book').click((e) => {
    e.preventDefault();
    var formData = new FormData(); //It creates a new FormData object to save the fields in the form
    formData.append('bookstitle', $('#bookTitle').val());
    formData.append('booksauthor', $('#bookAuthor').val());
    formData.append('booksgenre', $("[name='genre']").val());
    formData.append('image', $('input[type=file]')[0].files[0]); 
    //var formData ={
    //    bookstitle: $('#bookTitle').val(),
    //    booksauthor: $('#bookAuthor').val(),
    //    booksgenre: $("[name='genre']").val(),
    //    image: $('input[type=file]')[0].files[0]
    //}

    $.ajax({
        type: 'POST',
        url: '/books/savedata',
        data: formData,
        enctype: 'multipart/form-data',
        processData: false,
        contentType: false,
        success: (data, status) => {
            if (status == 'success')
                alert('Data saved successfully!')
                clearBook();
        }
    })
})

function clearBook(){
    $('#bookTitle').val('');
    $('#bookAuthor').val('');
    $("[name='genre']").val('');
    $('input[type=file]').val();
}

function loadBookList() {
    $.ajax({
        type: 'GET',
        url: '/books/getfromdb',
        success: (data, status) => {
            printData(JSON.parse(data));
            console.log(JSON.parse(data))
        }
    })
}

function printData(allRows){
    var toPrint = '';

    allRows.forEach(row => {
        var imageSrc = `temp/${row.image}`;
        toPrint += `<div class="col-4" style="text-align: center;">
                        <div class="card" style="width: 18rem; background-color: transparent; border: 0px; position: relative">
                            <img src="${imageSrc}" class="card-img-top" style=" border-radius: 0px; height: 444px;">
                            <div class="card-body">
                              <p style="font-size: 25px;">${row.bookstitle}</p>
                              <p style="margin-top: -5%;">Author: ${row.booksauthor}</p>
                              <p style="margin-top: -5%; font-size: 13px;">Genre: ${row.booksgenre}</p>
                            <p style="margin-top: -5%;"><button onclick=\'editBook(${JSON.stringify(row)})\' style="border: 0px; font-size: 13px; background-color: transparent;">Edit</button><button onclick="deleteBook(${row.booksid})" style="border: 0px; font-size: 13px; background-color: transparent;">Remove</button></p>
                            </div>
                        </div>
                    </div>`
    })
    $('#print-book').html(toPrint);
}

function deleteBook(id){
    $.ajax({
        url: `/books/deletebook/${id}`,
        type: 'DELETE',
        success: (data, status) => {
            if (status === 'success'){
                alert('Book deleted successfully!');
                loadBookList();
            }
        }
    })
}

function editBook(books){
    $('#utitle').val(books.bookstitle);
    $('#uauthor').val(books.booksauthor);
    $("[name='ugenre']").val(books.booksgenre);
    $('input[type=file]').val();
    $('#ubookid').val(books.booksid);
    $('#editBookModal').modal('show');
}

function saveBookChanges(){
    var formData = new FormData(); //It creates a new FormData object to save the fields in the form
    formData.append('bookstitle', $('#utitle').val());
    formData.append('booksauthor', $('#uauthor').val());
    formData.append('booksgenre', $("[name='ugenre']").val());
    formData.append('image', $('input[type=file]')[0].files[0]); 
    var id = $('#uid').val();

    $.ajax({
        url: `/books/updatebook/${id}`,
        type: 'POST',
        data: formData,
        success: (data, status) => {
            if (status === 'success'){
                alert('Book updated successfully!');
                $('#editBookModal').modal('hide');
                loadBookList();
            }
        }
    })
}


/******************RENT SCRIPTS******************/

function fillSelectBooks() {
    $('#selecttitle').html("<option value=''></option>");
    $('#selecttitle').select2({placeholder: "Select a book"});
    getRequest('/rents/fillbook/query?col=*', data => {
        let options = "";
        for (let i = 0; i< data.length; i++){
            let title = `${data[i].bookstitle}`;
            options += `<option value="${title}">${title}</option>`
        }
        $("#selecttitle").append(options);
    })
}

function fillUSelectBooks() {
    $('#uselecttitle').html("<option value=''></option>");
    $('#uselecttitle').select2({placeholder: "Select a book"});
    getRequest('/rents/fillbook/query?col=*', data => {
        let options = "";
        for (let i = 0; i< data.length; i++){
            let title = `${data[i].bookstitle}`;
            options += `<option value="${title}">${title}</option>`
        }
        $("#uselecttitle").append(options);
    })
}

function fillSelectNames() {
    $('#selectname').html("<option value=''></option>");
    $('#selectname').select2({placeholder: "Select a reader"});
    getRequest('/rents/fillcust/query?col=*', data => {
        let options = "";
        for (let i = 0; i< data.length; i++){
            let name = `${data[i].customersfname}`;
            options += `<option value="${name}">${name}</option>`
        }
        $("#selectname").append(options);
    })
}

function fillUSelectNames() {
    $('#uselectname').html("<option value=''></option>");
    $('#uselectname').select2({placeholder: "Select a reader"});
    getRequest('/rents/fillcust/query?col=*', data => {
        let options = "";
        for (let i = 0; i< data.length; i++){
            let name = `${data[i].customersfname}`;
            options += `<option value="${name}">${name}</option>`
        }
        $("#uselectname").append(options);
    })
}

function rentBook(){
    var formData ={
        loansdate: $('#rentDate').val(),
        loansreturn: $('#returnDate').val(),
        loanscustomer: $("[name='selectnameid']").val(),
        loansbook: $("[name='selecttitleid']").val()
    }

    $.ajax({
        url: '/rents/saverent',
        type: 'POST',
        data: formData,
        success: function (data, status) {
            if (status === 'success'){
                console.log('Rent Saved Successfully!')
                listRents();	
            }
        }
    })
}

function listRents(){
    $.ajax({
        url: '/rents/listrents',
        type: 'GET',
        success: (data, status) => {
            if (status === 'success'){
                displayRents(JSON.parse(data));
            }
        }
    })
}

function displayRents(rent){
    toPrint ='';

    rent.forEach(rents =>{
        toPrint += `<tr>
                        <td>${rents.loansdate}</td>
                        <td>${rents.loansreturn}</td>
                        <td>${rents.loanscustomer}</td>
                        <td>${rents.loansbook}</td>
                        <td style="padding:0">
                        <button class="btn btn-link" onclick="deleteRent(${rents.loansid})"><i class="fa fa-trash"></i></button>
                        <button class="btn btn-link" onclick=\'editRent(${JSON.stringify(rents)})\'><i class="fa fa-edit"></i></button>
                    </td>
                </tr>`
    });

    $('#print-rent').html(toPrint);
}

function deleteRent(id){
    $.ajax({
        url: `/rents/deleterent/${id}`,
        type: 'DELETE',
        success: (data, status) => {
            if (status === 'success'){
                alert('Rent deleted successfully!');
                listRents();
            }
        }
    })
}

function editRent(rents){
    fillUSelectBooks();
    fillUSelectNames();
    $('#udate').val(rents.loansdate);
    $('#ureturn').val(rents.loansreturn);
    $("[name='uselectnameid']").val(rents.loanscustomer);
    $("[name='uselecttitleid']").val(rents.loansbook);
    $('#urentid').val(rents.loansid);
    $('#editRentModal').modal('show');
}

function saveRentChanges(){
    var formData ={
        loansdate: $('#udate').val(),
        loansreturn: $('#ureturn').val(),
        loanscustomer:  $("[name='uselectnameid']").val(),
        loansbook:  $("[name='uselecttitleid']").val()
    }
    var id = $('#urentid').val();

    $.ajax({
        url: `/rents/updaterent/${id}`,
        type: 'POST',
        data: formData,
        success: (data, status) => {
            if (status === 'success'){
                alert('Rent updated successfully!');
                $('#editRentModal').modal('hide');
                listRents();
            }
        }
    })
}