var express = require('express');
var conn = require('../dbconnection/dbconnect');

var router = express.Router();

router.get('/addcust', (req, res) => {
    res.render('addcust');
});

router.get('/listcust', (req, res) => {
    res.render('listcust');
});

router.post('/customers/savecust', (req, res) => {
    var form = req.body;
    var sqlCmd = 'INSERT INTO customers SET ?';
    conn.query(sqlCmd, form, (error, result) => {
        if (error) console.log(error);
        else res.end();
    })
})

router.get('/customers/listreaders', (req, res) => {
    var sqlCmd = 'SELECT * FROM customers';
    conn.query(sqlCmd, (error, result) => {
        if (error) console.log(error);
        else res.end(JSON.stringify(result)); 
    })
})

router.delete('/customers/deletecustomer/:id', (req, res) => {
    var id = req. params.id;
    sqlCmd = `DELETE FROM customers WHERE customersid = ${id}`;
    conn.query(sqlCmd, (error, result) => {
        if (error) console.log(error);
        else res.end();
    })
})

router.post('/customers/updatecustomer/:id', (req, res) => {
    var id = req.params.id;
    var form = req.body;

    var sqlCmd = `UPDATE customers SET ? WHERE customersid = ?`;
    conn.query(sqlCmd, [form, id], (error, result) => {
        if (error) console.log(error);
        else res.end();
    })
})



module.exports = router;
