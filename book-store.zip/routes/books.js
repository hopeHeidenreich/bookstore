var express = require('express');
var router = express.Router();
const multer = require('multer');
const app = require('../app');
const formidable = require('formidable');
let multiparty = require('multiparty');
let fs = require('fs');


var conn = require('../dbconnection/dbconnect');

router.get('/listbook', (req, res) => {
    res.render('listbook');
});

router.get('/addbook', (req, res) => {
    res.render('addbook');
});

router.post('/books/savedata', (req, res) => {
    const form = new formidable.IncomingForm();

    form.parse(req, function (err, fields, files) {
        console.log(files.image)
        var oldpath = files.image.filepath;
        var newpath = 'public/temp/' + files.image.originalFilename;
        fs.copyFile(oldpath, newpath, function (err) {
            if (err) throw err;
        });
    });

    var formData = new multiparty.Form();
    formData.parse(req, (error, fields, files) => {
        var rowData = {
            bookstitle: fields.bookstitle,
            booksauthor: fields.booksauthor,
            booksgenre: fields.booksgenre,
            image: files.image[0].originalFilename
        };
        var sqlCmd = 'INSERT INTO books SET ?';
        conn.query(sqlCmd, rowData, (error, result) => {
            if (error) throw error;
            res.end();
        })
    })
})

router.get('/books/getfromdb', (req, res) => {
    var sqlCmd = 'SELECT * FROM books';
    conn.query(sqlCmd, (error, result) => {
        if (error) throw error;
        else res.end(JSON.stringify(result)); 
    })
})

router.delete('/books/deletebook/:id', (req, res) => {
    var id = req. params.id;
    sqlCmd = `DELETE FROM books WHERE booksid = ${id}`;
    conn.query(sqlCmd, (error, result) => {
        if (error) console.log(error);
        else res.end();
    })
})

router.post('/books/updatebook/:id', (req, res) => {
    var id = req.params.id;
    var form = req.body;

    var sqlCmd = `UPDATE books SET ? WHERE booksid = ?`;
    conn.query(sqlCmd, [form, id], (error, result) => {
        if (error) console.log(error);
        else res.end();
    })
})



module.exports = router;
