var express = require('express');
var conn = require('../dbconnection/dbconnect');

var router = express.Router();

router.get('/', function(req, res, next) {
    res.render('index');
})

module.exports = router;
