var express = require('express');
var conn = require('../dbconnection/dbconnect');

var router = express.Router();

router.get('/listrent', (req, res) => {
    res.render('listrent');
});

router.get("/rents/fillcust/query", (req, res) => {
    var sqlCmd;
    if (req.query.where === undefined) {
        sqlCmd = `SELECT ${req.query.col} FROM customers;`;
        console.log(sqlCmd);}
    else 
        sqlCmd = `SELECT ${req.query.col} FROM customers WHERE customersid = ${req.query.where};`;
    conn.query(sqlCmd, (err, result) => {
        if (err) {
            console.log(err);
            res.status(404).send("Failed Getting Query");
        }
        else {
            console.log("Responding with customers query");
            res.status(200).send(result);
        }
    });
});

router.get("/rents/fillbook/query", (req, res) => {
    var sqlCmd;
    if (req.query.where === undefined) {
        sqlCmd = `SELECT ${req.query.col} FROM books;`;
        console.log(sqlCmd);}
    else 
        sqlCmd = `SELECT ${req.query.col} FROM books WHERE booksid = ${req.query.where};`;
    conn.query(sqlCmd, (err, result) => {
        if (err) {
            console.log(err);
            res.status(404).send("Failed Getting Query");
        }
        else {
            console.log("Responding with books query");
            res.status(200).send(result);
        }
    });
});

router.post('/rents/saverent', (req, res) => {
    var form = req.body;
    var sqlCmd = 'INSERT INTO loans SET ?';
    conn.query(sqlCmd, form, (error, result) => {
        if (error) console.log(error);
        else res.end();
    })
});

router.get('/rents/listrents', (req, res) => {
    var sqlCmd = 'SELECT * FROM loans';
    conn.query(sqlCmd, (error, result) => {
        if (error) console.log(error);
        else res.end(JSON.stringify(result));
    })
})

router.delete('/rents/deleterent/:id', (req, res) => {
    var id = req. params.id;
    sqlCmd = `DELETE FROM loans WHERE loansid = ${id}`;
    conn.query(sqlCmd, (error, result) => {
        if (error) console.log(error);
        else res.end();
    })
})

router.post('/rents/updaterent/:id', (req, res) => {
    var id = req.params.id;
    var form = req.body;

    var sqlCmd = `UPDATE loans SET ? WHERE loansid = ?`;
    conn.query(sqlCmd, [form, id], (error, result) => {
        if (error) console.log(error);
        else res.end();
    })
})

module.exports = router;
